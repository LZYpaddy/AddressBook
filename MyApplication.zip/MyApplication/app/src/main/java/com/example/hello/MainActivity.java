package com.example.hello;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.entity.friend;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
private List<friend> friends =new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
        FriendAdapter adapter = new FriendAdapter(MainActivity.this, R.layout.friend_item, friends);
        ((ListView) findViewById(R.id.friendList)).setAdapter(adapter);
    }

    private void init() {
        friends.add(new friend("小明",R.mipmap.ic_launcher));
        friends.add(new friend("小2",R.mipmap.ic_launcher));
        friends.add(new friend("小3",R.mipmap.ic_launcher));
        friends.add(new friend("小5",R.mipmap.ic_launcher));
        friends.add(new friend("小8",R.mipmap.ic_launcher));
        friends.add(new friend("小9",R.mipmap.ic_launcher));
        friends.add(new friend("小红",R.mipmap.ic_launcher));
    }
}
